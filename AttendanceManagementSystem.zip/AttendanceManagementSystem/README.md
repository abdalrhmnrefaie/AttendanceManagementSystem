# Attendance-Management-System

simple javaFX SWING application using txt file to store records

<a href="https://www.buymeacoffee.com/amokhtar" target="_blank"><img src="https://www.buymeacoffee.com/assets/img/custom_images/orange_img.png" alt="Buy Me A Coffee" style="height: 41px !important;width: 174px !important;box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;-webkit-box-shadow: 0px 3px 2px 0px rgba(190, 190, 190, 0.5) !important;" ></a>

application uml: 

![](images/uml.png)

application starts with simple form:

![](images/1.png)

Login Form:

![](images/2.png)

Validating user input based on stored data(in txt file):

![](images/3.png)

Admin page:

![](images/5.png)

Adding/Deleting students:

![](images/6.png)

Showing the data of all exsisting students:

![](images/7.png)

Admin can mark student as absent or present:

![](images/4.png)
 
Student can see his attendance percentage and shows warning ig the absent percentage is 20% or more:

![](images/8.png)

